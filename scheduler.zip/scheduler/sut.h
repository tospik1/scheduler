#ifndef __SUT_H__
#define __SUT_H__
#include <stdbool.h>

typedef void (*sut_task_f)();

void sut_init();
bool sut_create(sut_task_f fn);
void sut_yield();
void sut_exit();

// Note: for all IO operations the file should exist to be successful
// in case of writing to file if the file doesn't exist it's not created
// files are always opened in read+write mode
// because in this api there's no way to control whether to open read-only or write-only
int sut_open(char *dest);
void sut_write(int fd, char *buf, int size);
void sut_close(int fd);
char *sut_read(int fd, char *buf, int size);

void sut_shutdown();

// This value is used to control how many c-exec to be created
#define num_computation_threads 2

#endif
