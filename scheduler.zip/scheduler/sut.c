﻿#include "sut.h"
#include "queue.h"
#include <ucontext.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <fcntl.h>

#define MAX_THREADS 50
#define THREAD_STACK_SIZE 1024*64
//#define MAX_COMP_THREADS 10

// Structure that contains required data for each task
typedef struct __threaddesc
{
    int threadid;
    char *threadstack;
    void *threadfunc;
    ucontext_t threadcontext;
} threaddesc;

// Structure for IO request
typedef struct __IoRequest
{
    int threadid;
    int fd;
    char* buf;
    int size;
    enum IoType {
        IO_OPEN, IO_CLOSE, IO_READ, IO_WRITE
    } iotype;
    char* path;
} IoRequest;

struct queue ready_q; // Used by c-exec
struct queue wait_q; // Used by i-exec

int numthreads; // Total number of tasks ever created
int remThreads; // Number of tasks not yet terminated
int curthread[num_computation_threads]; // Id of task each c-exec is running
ucontext_t c_exec_ctx[num_computation_threads]; // Contexts for each c-exec
pthread_t c_exec_th[num_computation_threads]; // Kernel level thread for each c-exec

ucontext_t i_exec_ctx; // Context for i-exec
pthread_t i_exec_th; // Kernel level thread for i-exec

threaddesc threadarr[MAX_THREADS]; // All tasks data

bool shutdown = false; // This is to control when to terminate cleanly

pthread_mutex_t ready_mutex = PTHREAD_MUTEX_INITIALIZER; // Used for ready queue
pthread_mutex_t wait_mutex = PTHREAD_MUTEX_INITIALIZER; // Used for io waiting queue
pthread_mutex_t create_thr_mutex = PTHREAD_MUTEX_INITIALIZER; // Used when creating new taks

// Returns the index of c-exec that is running at this time
// It's used to correctly find which taks does sut_yield or other action
int getThreadIndex();

// Main loop for c-exec, running until shutdown is done
void* runCExec(void* data);

// Main loop for i-exec, running until shutdown is done
void* runIExec(void* data);
//void sut_init();
//bool sut_create(sut_task_f fn);
//void sut_yield();
//void sut_exit();

// Helper function to avoid code repetition
// all of IO requests are done similar way
IoRequest* prepareIORequest(enum IoType io_type, int fd, char* buf, int size, char* path);

int getThreadIndex() {
    pthread_t thread = pthread_self(); // Get current thread struct
    for  (int i = 0; i < num_computation_threads; ++i) {
        if (c_exec_th[i] == thread) {
            return i;
        }
    }
    printf("Impossible: thread not found\n");
}

void* runCExec(void* data) {
    while (true) {
        pthread_mutex_lock(&ready_mutex);
        struct queue_entry* ent = queue_pop_head(&ready_q);
        pthread_mutex_unlock(&ready_mutex);
        if (ent) {
            threaddesc* cur = (threaddesc*) ent->data;
            int thrInd = getThreadIndex();
            curthread[thrInd] = cur->threadid; // Set it to remember which task current c-exec is running
            swapcontext(&c_exec_ctx[thrInd], &(cur->threadcontext)); // Switch to task's current position and execute
        } else {
            if (shutdown && remThreads==0) { // Cleanly shutdown if shutdown requirement is made and no more tasks to do
                break;
            }
            usleep(100); // 100 milliseconds sleep if nothing to do, if there are still tasks to do, all are done without pause
        }
    }
}
void* runIExec(void* data) {
    while (true) {
        pthread_mutex_lock(&wait_mutex);
        struct queue_entry* ent = queue_pop_head(&wait_q);
        pthread_mutex_unlock(&wait_mutex);
        if (ent) {
            IoRequest* cur = (IoRequest*) ent->data;
            // Now here actual io operation is done, result is put on IoRequest struct
            // and when context switches back to the task (in sut_open and other functions)
            // data can be taken from the request
            if (cur->iotype == IO_OPEN) {
                cur->fd = open(cur->path, O_RDWR);
            } else if (cur->iotype == IO_WRITE) {
                write(cur->fd, cur->buf, cur->size);
            } else if (cur->iotype == IO_READ) {
                if (read(cur->fd, cur->buf, cur->size) == 0) {
                    cur->buf[0] = '\0'; // Need to notify if read has failed
                }
            } else if (cur->iotype == IO_CLOSE) {
                close(cur->fd);
            } else {
                printf("Impossible: Other io type is requested by threadid %d\n", cur->threadid);
            }
            struct queue_entry *node = queue_new_node(&(threadarr[cur->threadid]));
            pthread_mutex_lock(&ready_mutex);
            queue_insert_tail(&ready_q, node);
            pthread_mutex_unlock(&ready_mutex);
        } else {
            if (shutdown && remThreads==0) { // Cleanly shutdown if shutdown requirement is made and no more tasks to do
                break;
            }
            usleep(100); // 100 milliseconds sleep if nothing to do, if there are still tasks to do, all are done without pause
        }
    }
}

void sut_init() {
    // At beginning none of c-exec threads doing any task
    for (int i = 0; i < num_computation_threads; ++i) {
        curthread[i] = -1;
    }
    // Create queues
    ready_q = queue_create();
    queue_init(&ready_q);
    wait_q = queue_create();
    queue_init(&wait_q);
    // Create kernel level threads
    for (int i = 0; i < num_computation_threads; ++i) {
        pthread_create(&c_exec_th[i], NULL, &runCExec, NULL);
    }
    pthread_create(&i_exec_th, NULL, &runIExec, NULL);
}


bool sut_create(sut_task_f fn) {
    // Mutex is used here, otherwise 2 threads would insert new task at same index
    pthread_mutex_lock(&create_thr_mutex);
    threaddesc *tdescptr = NULL;

    if (numthreads >= MAX_THREADS)
    {
        printf("FATAL: Maximum thread limit reached... creation failed! \n");
        return -1;
    }

    // Initialize required data for task
    tdescptr = &(threadarr[numthreads]);
    getcontext(&(tdescptr->threadcontext));
    tdescptr->threadid = numthreads;
    tdescptr->threadstack = (char *)malloc(THREAD_STACK_SIZE);
    tdescptr->threadcontext.uc_stack.ss_sp = tdescptr->threadstack;
    tdescptr->threadcontext.uc_stack.ss_size = THREAD_STACK_SIZE;
    tdescptr->threadcontext.uc_link = 0;
    tdescptr->threadcontext.uc_stack.ss_flags = 0;
    tdescptr->threadfunc = fn;

    makecontext(&(tdescptr->threadcontext), fn, 0);

    numthreads++;
    remThreads++;
    pthread_mutex_unlock(&create_thr_mutex);

    struct queue_entry *node = queue_new_node(tdescptr);
    pthread_mutex_lock(&ready_mutex);
    queue_insert_tail(&ready_q, node);
    pthread_mutex_unlock(&ready_mutex);

    return true;
}

void sut_yield() {
    // Task id is found and pushed again in ready queue
    int thrId = getThreadIndex();
    struct queue_entry *node = queue_new_node(&(threadarr[curthread[thrId]]));
    pthread_mutex_lock(&ready_mutex);
    queue_insert_tail(&ready_q, node);
    pthread_mutex_unlock(&ready_mutex);
    swapcontext(&(threadarr[curthread[thrId]].threadcontext), &c_exec_ctx[thrId]);
}
void sut_exit() {
    // Here task is no more putted at ready queue
    int thrId = getThreadIndex();
    remThreads--; // Task finished, keeping count
    swapcontext(&(threadarr[curthread[thrId]].threadcontext), &c_exec_ctx[thrId]);
}

IoRequest* prepareIORequest(enum IoType io_type, int fd, char* buf, int size, char* path) {
    int thrId = getThreadIndex();
    IoRequest* req = malloc(sizeof(IoRequest));
    // Set request data
    req->iotype = io_type;
    req->threadid = curthread[thrId];
    req->fd = fd;
    req->buf = buf;
    req->size = size;
    req->path = path;
    struct queue_entry *node = queue_new_node(req);
    pthread_mutex_lock(&wait_mutex);
    queue_insert_tail(&wait_q, node);
    pthread_mutex_unlock(&wait_mutex);
    // Here execution is paused and io request will be handled by i-exec
    // after i-exec handles it the result will be available inside request struct
    // including in case of failure to do the request, appropriate values are set
    // after calling this function, the IoRequest should be freed
    swapcontext(&(threadarr[curthread[thrId]].threadcontext), &c_exec_ctx[thrId]);
    return req;
}

int sut_open(char *dest) {;
    IoRequest* req = prepareIORequest(IO_OPEN, -1, NULL, -1, dest);
    int fd = req->fd;
    free(req);
    return fd;
}
void sut_write(int fd, char *buf, int size) {
    IoRequest* req = prepareIORequest(IO_WRITE, fd, buf, size, NULL);
    free(req);
}
void sut_close(int fd) {
    IoRequest* req = prepareIORequest(IO_CLOSE, fd, NULL, -1, NULL);
    free(req);
}
char *sut_read(int fd, char *buf, int size) {
    IoRequest* req = prepareIORequest(IO_READ, fd, buf, size, NULL);
    free(req);
    if (buf[0] == '\0') { // Check if read has failed return NULL
        return NULL;
    }
    return buf;
}
void sut_shutdown() {
    shutdown = true; // Now c-exec(s) and i-exec will see this and will return when no more tasks to do
    for (int i = 0; i < num_computation_threads; ++i) {
        pthread_join(c_exec_th[i], NULL); // Wait all c-exec threads to finish and return
    }
    pthread_join(i_exec_th, NULL); // Wait i-exec thread to finish and return
}



