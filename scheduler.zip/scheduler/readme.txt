To change the number of C-EXEC's to run, change the value of num_computation_threads located in sut.h I sent (note that this wasn't been there in original file, and was needed to add it)

All files for doing IO is opened in read+write mode, since in api there's no way to decide which mode to open file with, and files are not created if they don't exist

Due to the fact that C-EXEC and I_EXEC process all the queue and then waits until new items come (with sleep), IO operations take slower and so they are usually processed later

This program can run with any number of C-EXEC threads, upto around 10 is ok to run
